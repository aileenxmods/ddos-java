clear
figlet ./XMODS
echo -e "\u001b[31m                          ( AileenXMods )"
echo -e  "\u001b[32m========================================"
echo "||       HALLO PENGGUNA PREMIUM        ||"
echo "========================================"
echo "Masukan Link Target"
echo "     CONTOH : https://contoh.com/"
echo ""
   python3 .ddosjava.py
#then
