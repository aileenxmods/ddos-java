
figlet ./XMODS
echo -e "\u001b[31m                          ( AileenXMods )"
echo -e  "\u001b[32m========================================"
echo "||       HALLO PENGGUNA GRATIS         ||"
echo "========================================"
echo " TINGGKAT KEBERHASILAN 45%"
echo " BUY PREMIUM 20K MURAH"
echo " BISA DIJUAL SC NYA, BISA OPEN MUR DDOS"
echo "=================[INFO]=================="
echo "Masukan Link Target"
echo "     CONTOH : https://contoh.com/"
echo ""
   python3 .free.py
#then
