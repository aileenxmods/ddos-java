import os
os.system("bash .logo.sh")

