clear
clear
neofetch
echo -e "\u001b[32m========================================"
echo -e "\u001b[13m  MASUKAN PASSWORD PREMIUM JIKA ADA  "
echo -e "\u001b[32m========================================"
read -p "Masukan Key1 [ ENTER jika Tidak Ada ] : " passs
if [ $passs = bayarcuy ]
then
    echo "Password Benar"
    echo " "
python3 .bh.py
else
clear
    echo -e "\u001b[32m========================================"
    echo -e "\u001b[31          PASSWORD SALAH"
    echo -e "\u001b[13m TELEGRAM : t.me/aileenxmods [@AileenXMods]"
    echo -e "\u001b[13m WHATSAPP : 62XXXXXXXXXX"
    echo -e "\u001b[32m========================================"
    echo " BUY KE OWNER KU"
bash .logof.sh
fi
