import os
os.system(" cd .modules && bash .login.sh")
