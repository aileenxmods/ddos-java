import os
os.system("cd && cd /sdcard/termux/h/.modules && bash .login.sh")
